# customer-segmentation-project
Customer segmentation using K-Means clustering in Python
